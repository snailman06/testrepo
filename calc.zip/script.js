function compute()
{
var plus = (principal+interest);
    document.getElementById('plus').innerHTML = plus;
var principal = parseint(document.getElementById('principal').value);
var rate = document.getElementById('rate').value;
var years = document.getElementById("years").value;
var target = (new Date().getFullYear() + parseInt(years));
    document.getElementById('target').innerHTML = target;

    /*Simple Interest Formula =
  p*r*t/100*/
var interest = (principal*years*rate)/100;
    document.getElementById('interest').innerHTML = interest;
    
  
}
function updateRate() 
{
    var rateval = document.getElementById("rate").value;
    document.getElementById("rate_val").innerText=rateval;
}

        