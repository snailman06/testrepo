function compute()
{
var plus = (principal + interest);
    document.getElementById('plus').innerHTML = plus;
var principal = (document.getElementById("principal")).value;
    document.getElementById('principal').innerHTML = principal;
var rate = (document.getElementById("rate").value);
    document.getElementById('rate').innerHTML = rate;
var years = (document.getElementById("years").value);

var year = (new Date().getFullYear() + parseInt(years));
    document.getElementById('year').innerHTML = year;

var interest = (principal * years * rate / 100);
    document.getElementById('interest').innerHTML = interest;
    
  
}
function updateRate() 
{
    var rateval = document.getElementById("rate").value;
    document.getElementById("rate_val").innerText=rateval;
}

        